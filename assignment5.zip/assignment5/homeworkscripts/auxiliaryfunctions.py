
def fn_message(name):
    print(name + ", you have successfully imported functions from a " +
          "python script.")